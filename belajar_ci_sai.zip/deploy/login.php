<?php session_start();?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Signin Template · Bootstrap v4.6</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.6/examples/sign-in/">    

    <!-- Bootstrap core CSS -->
    <link href="../login/assets/dist/css/bootstrap.min.css" rel="stylesheet">



    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
<?php
  if(isset($_SESSION['username'])) {
        header('Location:http://localhost/Belajarphp/daftar_kontak.php');
      exit();
    }

  if (isset($_POST['submit'])) {
    
  //$available_user = 'admin';
  //$available_pass = '12345678';
  include "../database.php";

  $username = $_POST['username'];
  $password = $_POST['password'];

  $sql = "SELECT `user_id`, `username`, `password` FROM `tb_user` WHERE `username` = '{$username}'";
  $data = $conn->query($sql)->fetch(PDO::FETCH_OBJ);

  //var_dump($data);
  if (!empty($data)) {
if ($password === $data->password) {
  $_SESSION['uid'] = $data->user_id;
  $_SESSION['username'] = $data->username;

  header('Location:http://localhost/Belajarphp/daftar_kontak.php');
    exit;
  } else {
    echo "<div class='alert alert-danger' role='alert'>PASSWORD SALAH!</div>";
  }
} else {
    echo "<div class='alert alert-danger' role='alert'>USERNAME TIDAK DITEMUKAN!</div>";
  }
}
?>

<form action="" method="post" class="form-signin">

  <h1 class="h3 mb-3 font-weight-normal">Please sign in</h1>
  
  <label for="username" class="sr-only">Username</label>
  <input type="text" id="username" name="username" class="form-control" 
  placeholder="Username" required autofocus>

  <label for="inputPassword" class="sr-only">Password</label>
  <input type="password" id="inputPassword" name="password" class="form-control" 
  placeholder="Password" required>

  <button class="btn btn-lg btn-primary btn-block" name="submit" type="submit">Sign in</button>
  <p class="mt-5 mb-3 text-muted">&copy; 2017-2021</p>
</form>


    
  </body>
</html>
